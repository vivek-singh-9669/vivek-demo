# LifeLink — Blood Bank Management System

MCSP-232 practical viva demo website.

## Features
- Responsive dashboard
- Donor registration and search/filter
- Blood inventory overview
- Blood request creation, filtering and fulfillment
- Organization management UI
- Appointment scheduling
- Reports & analytics
- Settings screen
- Toast notifications and interactive modals
- Mobile-friendly sidebar
- No backend required for the demo; data is held in JavaScript for the current session

## Run
Open `index.html` in a browser.

## GitHub Pages
Upload `index.html` to a repository and enable GitHub Pages from Settings → Pages → Deploy from branch.

## Viva talking points
Architecture: client-side web application with modular pages and centralized data structures.
Security/production note: a real deployment should add authentication, role-based access, server-side validation, encrypted transport, audit logs and a database.
